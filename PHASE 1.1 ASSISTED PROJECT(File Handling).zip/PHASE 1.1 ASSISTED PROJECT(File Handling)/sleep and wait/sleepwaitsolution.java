package assistedprojectsleepwait;


public class sleepwaitsolution {
	
	private static Object LOCK= new Object();
	
	public static void main(String[] args) {
		
	
			try {
				
				Thread.sleep(2000);
				System.out.println(Thread.currentThread().getName()+ " is  woke up after "
						+ "2 second  of  sleep");
				
				synchronized (LOCK) {
					LOCK.wait(3000);
					System.out.println("Object is woke up after wait of  3 seconds");
					
				}
				}
			catch (InterruptedException e) {
				
				e.printStackTrace();
				
				System.out.println("Error Occured: "+e);
			}
			}
}