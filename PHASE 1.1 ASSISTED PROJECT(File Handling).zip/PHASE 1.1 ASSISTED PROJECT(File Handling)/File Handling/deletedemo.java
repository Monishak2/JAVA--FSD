package filehandlingdemo;
import java.io.File;
public class deletedemo {
public static void main (String[] args)
{
	File myfile = new  File("demo2.txt");
	if(myfile.delete())
	{ 
		System.out.println("File is deleted: " +myfile.getName()+ "File is deleted successfully");
	}
	else {
		System.out.println("File is not created");
	}
}
}
