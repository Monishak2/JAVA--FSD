package synchronization;



public class TestSynchronization {
	
	public static void main(String[] args) {
		
		Sender sender = new Sender();
		
		user t1= new user("Akash", "Hello Good morning....!", sender);
		user t2= new user("Ashwin","Hii!! how  are you?",sender);
		
		t1.start();
		t2.start();
	}

}