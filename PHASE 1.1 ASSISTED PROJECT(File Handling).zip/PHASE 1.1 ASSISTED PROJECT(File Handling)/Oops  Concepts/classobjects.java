package oopsconcepts;

public class classobjects 
{  
    String name; 
    int age; 
    String place; 
    public classobjects(String name, int age, String place) 
    { 
        this.name = name; 
        this.age = age; 
        this.place = place; 
    } 
    public String getName() 
    { 
        return name; 
    }  
    public int getAge() 
    { 
        return age; 
    } 
    public String getplace() 
    { 
        return place; 
    } 
   
    public String toString() 
    { 
        return("Hi my name is "+ this.getName() +"\nI am " +this.getAge()+ "and I am from"+ this.getplace() + "."); 
    } 
    public static void main(String[] args) 
    { 
        classobjects verify = new classobjects("janu", 15, "chennai"); 
        System.out.println(verify.toString()); 
    } 
}
