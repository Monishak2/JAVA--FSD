package exceptionhandling;

public class throwsdemo 
    {
        void Division() throws ArithmeticException
        {
            int a=55,b=5,rs;
             rs = a / b;
            System.out.print("\nThe result is : " + rs);
        }
         public static void main(String[] args)
        {
         throwsdemo T = new throwsdemo();
             try
            {
                T.Division();
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("\nError : " + Ex.getMessage());
            }
            System.out.print("\nEnd of program.");
        }
    }
