package exceptionhandling;

public class finallydemo 
{
    public static void main(String[] args)
    {
        int a=48,b=8,rs=0;
        try
        {
            rs = a / b;
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\nError : " + Ex.getMessage());
        }
        finally
        {
            System.out.print("\nThe result is : " + rs);
        }
    }
}
