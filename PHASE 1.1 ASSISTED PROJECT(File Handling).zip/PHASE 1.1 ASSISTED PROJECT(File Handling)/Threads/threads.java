package assprojectthreads;



public class threads extends Thread {
	
	public void run() {
		System.out.println("thread Started");
	}
	
	public static void main(String[] args) {
		
		threads t1= new threads();
		threads t2= new threads();
		
		t1.start();
		t2.start();
	}

}